package com.example.exam_preda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
